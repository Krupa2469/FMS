/*==========================================================
 Project     : Government File Management System (FMS)
 Module      : CPGRAMS
 File        : cpgrams.js
 Version     : 4.1
 Developer   : Lekha Technologies
 Description : CPGRAMS Controller
==========================================================*/

"use strict";

/*==========================================================
 GLOBAL VARIABLES
==========================================================*/

let currentDocumentId = null;
let currentGrievance = null;
let editMode = false;
let formDirty = false;

/*==========================================================
 PAGE INITIALIZATION
==========================================================*/

document.addEventListener("DOMContentLoaded", initializePage);

/*==========================================================
 INITIALIZE PAGE
==========================================================*/

async function initializePage() {

    try {

        console.log("==================================");
        console.log("CPGRAMS Version 4.1");
        console.log("Lekha Technologies");
        console.log("==================================");

        registerButtonEvents();

        registerFieldEvents();

        await loadMasterData();

        clearForm();

        console.log("CPGRAMS Loaded Successfully");

    }
    catch (error) {

        console.error(error);

        showMessage(
            error.message,
            "danger"
        );

    }

}

/*==========================================================
 REGISTER BUTTON EVENTS
==========================================================*/

function registerButtonEvents() {

    bindClick("btnNew", clearForm);

    bindClick("btnSave", saveGrievance);

    bindClick("btnUpdate", updateGrievance);

    bindClick("btnDelete", confirmDelete);

    bindClick("btnRegister", openRegister);

    bindClick("btnDashboard", openDashboard);

    bindClick("btnPrint", printGrievance);

    bindClick("btnHome", goHome);

}

/*==========================================================
 REGISTER FIELD EVENTS
==========================================================*/

function registerFieldEvents() {

    bindChange(
        "dateReceived",
        calculateDueDate
    );

    bindChange(
        "district",
        districtChanged
    );

    bindChange(
        "mandal",
        mandalChanged
    );

    bindChange(
        "priority",
        markDirty
    );

    bindChange(
        "category",
        markDirty
    );

    bindChange(
        "assignedOfficer",
        markDirty
    );

    document
        .querySelectorAll(
            "#cpgramsForm input,#cpgramsForm textarea,#cpgramsForm select"
        )
        .forEach(control => {

            control.addEventListener(
                "input",
                markDirty
            );

        });

}

/*==========================================================
 BUTTON HELPER
==========================================================*/

function bindClick(id, callback) {

    const control =
        document.getElementById(id);

    if (!control) {

        console.warn(id + " not found.");

        return;

    }

    control.addEventListener(
        "click",
        callback
    );

}

/*==========================================================
 CHANGE HELPER
==========================================================*/

function bindChange(id, callback) {

    const control =
        document.getElementById(id);

    if (!control) {

        console.warn(id + " not found.");

        return;

    }

    control.addEventListener(
        "change",
        callback
    );

}

/*==========================================================
 MARK FORM DIRTY
==========================================================*/

function markDirty() {

    formDirty = true;

}

/*==========================================================
 RESET EDIT MODE
==========================================================*/

function resetEditMode() {

    currentDocumentId = null;

    currentGrievance = null;

    editMode = false;

    formDirty = false;

}

/*==========================================================
 GENERATE GRIEVANCE ID
==========================================================*/

function generateGrievanceId() {

    const now = new Date();

    const yyyy = now.getFullYear();

    const mm =
        String(now.getMonth() + 1)
        .padStart(2, "0");

    const dd =
        String(now.getDate())
        .padStart(2, "0");

    const hh =
        String(now.getHours())
        .padStart(2, "0");

    const mi =
        String(now.getMinutes())
        .padStart(2, "0");

    const ss =
        String(now.getSeconds())
        .padStart(2, "0");

    document
        .getElementById("grievanceId")
        .value =
        `CPG-${yyyy}${mm}${dd}-${hh}${mi}${ss}`;

}

/*==========================================================
 CALCULATE DUE DATE
 CPGRAMS = 21 DAYS
==========================================================*/

function calculateDueDate() {

    const value =
        document
        .getElementById("dateReceived")
        .value;

    if (!value)
        return;

    const due =
        new Date(value);

    due.setDate(
        due.getDate() + 21
    );

    document
        .getElementById("dueDate")
        .value =
        due
        .toISOString()
        .substring(0,10);

}

/*==========================================================
 LOAD MASTER DATA
==========================================================*/

async function loadMasterData() {

    try {

        console.log("Loading Master Data...");

        await loadDistricts();

        await loadPriorities();

        await loadOfficers();

        await loadSections();

        console.log("Master Data Loaded");

    }
    catch(error){

        console.error(error);

    }

}

/*==========================================================
 DISTRICT CHANGED
==========================================================*/

async function districtChanged() {

    const district =
        getControlValue("district");

    await loadMandals(district);

    clearDropdown("village");

}

/*==========================================================
 MANDAL CHANGED
==========================================================*/

async function mandalChanged() {

    const district =
        getControlValue("district");

    const mandal =
        getControlValue("mandal");

    await loadVillages(
        district,
        mandal
    );

}

/*==========================================================
 COMMON HELPERS
==========================================================*/

function getControlValue(id){

    const control =
        document.getElementById(id);

    if(!control)
        return "";

    return control.value.trim();

}

function setControlValue(id,value){

    const control =
        document.getElementById(id);

    if(control)
        control.value=value;

}

function clearDropdown(id){

    const ddl =
        document.getElementById(id);

    if(!ddl)
        return;

    ddl.innerHTML =
        '<option value="">Select</option>';

}
/*==========================================================
 VALIDATION
==========================================================*/

function validateForm() {

    clearMessage();

    const requiredFields = [

        ["grievanceNumber", "Grievance Number"],
        ["dateReceived", "Date Received"],
        ["complainantName", "Complainant Name"],
        ["subject", "Subject"],
        ["grievanceDescription", "Grievance Description"]

    ];

    for (const field of requiredFields) {

        const control = document.getElementById(field[0]);

        if (!control)
            continue;

        if (control.value.trim() === "") {

            showMessage(
                field[1] + " is required.",
                "warning"
            );

            control.focus();

            return false;

        }

    }

    if (!validateMobile())
        return false;

    return true;

}

/*==========================================================
 MOBILE VALIDATION
==========================================================*/

function validateMobile() {

    const mobile =
        getControlValue("mobileNumber");

    if (mobile === "")
        return true;

    if (!/^[0-9]{10}$/.test(mobile)) {

        showMessage(
            "Mobile Number must contain exactly 10 digits.",
            "warning"
        );

        document
            .getElementById("mobileNumber")
            .focus();

        return false;

    }

    return true;

}

/*==========================================================
 HYBRID VALUE
 DROPDOWN + MANUAL ENTRY
==========================================================*/

function getHybridValue(dropdownId, textboxId) {

    const manual =
        getControlValue(textboxId);

    if (manual !== "")
        return manual;

    return getControlValue(dropdownId);

}

/*==========================================================
 BUILD OBJECT
==========================================================*/

function buildGrievanceObject() {

    const grievance = {};

    document
        .querySelectorAll(
            "#cpgramsForm input,#cpgramsForm select,#cpgramsForm textarea"
        )
        .forEach(control => {

            grievance[control.id] =
                control.value.trim();

        });

    /*
       Hybrid Location Fields
       Manual Entry gets preference
    */

    grievance.district =
        getHybridValue(
            "district",
            "districtManual"
        );

    grievance.mandal =
        getHybridValue(
            "mandal",
            "mandalManual"
        );

    grievance.village =
        getHybridValue(
            "village",
            "villageManual"
        );

    grievance.createdOn =
        grievance.createdOn || new Date();

    grievance.updatedOn =
        new Date();

    grievance.status =
        grievance.currentStatus || "Pending";

    grievance.version =
        "4.1";

    return grievance;

}

/*==========================================================
 DUPLICATE CHECK
==========================================================*/

async function validateDuplicate() {

    const grievanceNumber =
        getControlValue(
            "grievanceNumber"
        );

    if (grievanceNumber === "")
        return false;

    const exists =
        await grievanceExists(
            grievanceNumber
        );

    if (
        exists &&
        currentDocumentId == null
    ) {

        showMessage(
            "Grievance Number already exists.",
            "danger"
        );

        document
            .getElementById(
                "grievanceNumber"
            )
            .focus();

        return false;

    }

    return true;

}

/*==========================================================
 FORMAT MOBILE
==========================================================*/

function formatMobileNumber() {

    const control =
        document.getElementById(
            "mobileNumber"
        );

    control.value =
        control.value.replace(
            /\D/g,
            ""
        );

    if (
        control.value.length > 10
    ) {

        control.value =
            control.value.substring(
                0,
                10
            );

    }

}

/*==========================================================
 NORMALIZE DATA
==========================================================*/

function normalizeData(grievance) {

    Object.keys(grievance)
        .forEach(key => {

            if (
                grievance[key] === null ||
                grievance[key] === undefined
            ) {

                grievance[key] = "";

            }

        });

    return grievance;

}

/*==========================================================
 SAVE GRIEVANCE
==========================================================*/

async function saveGrievance() {

    try {

        clearMessage();

        if (!validateForm())
            return;

        if (!await validateDuplicate())
            return;

        showLoading();

        let grievance = buildGrievanceObject();

        grievance = normalizeData(grievance);

        grievance.createdOn = new Date();

        grievance.updatedOn = new Date();

        const result =
            await createRecord(grievance);

        hideLoading();

        if (!result.success) {

            showMessage(
                result.message,
                "danger"
            );

            return;

        }

        currentDocumentId = result.id;

        editMode = true;

        formDirty = false;

        showMessage(
            "Grievance saved successfully.",
            "success"
        );

    }
    catch (error) {

        hideLoading();

        console.error(error);

        showMessage(
            error.message,
            "danger"
        );

    }

}

/*==========================================================
 UPDATE
==========================================================*/

async function updateGrievance() {

    try {

        clearMessage();

        if (currentDocumentId == null) {

            showMessage(
                "Please search and open a grievance before updating.",
                "warning"
            );

            return;

        }

        if (!validateForm())
            return;

        showLoading();

        let grievance =
            buildGrievanceObject();

        grievance =
            normalizeData(grievance);

        grievance.updatedOn =
            new Date();

        const result =
            await updateRecord(
                currentDocumentId,
                grievance
            );

        hideLoading();

        if (!result.success) {

            showMessage(
                result.message,
                "danger"
            );

            return;

        }

        formDirty = false;

        showMessage(
            "Grievance updated successfully.",
            "success"
        );

    }
    catch (error) {

        hideLoading();

        console.error(error);

        showMessage(
            error.message,
            "danger"
        );

    }

}

/*==========================================================
 DELETE
==========================================================*/

async function deleteGrievance() {

    try {

        clearMessage();

        if (currentDocumentId == null) {

            showMessage(
                "No grievance selected.",
                "warning"
            );

            return;

        }

        showLoading();

        const result =
            await deleteRecord(
                currentDocumentId
            );

        hideLoading();

        if (!result.success) {

            showMessage(
                result.message,
                "danger"
            );

            return;

        }

        showMessage(
            "Grievance deleted successfully.",
            "success"
        );

        clearForm();

    }
    catch (error) {

        hideLoading();

        console.error(error);

        showMessage(
            error.message,
            "danger"
        );

    }

}

/*==========================================================
 DELETE CONFIRMATION
==========================================================*/

function confirmDelete() {

    if (currentDocumentId == null) {

        showMessage(
            "No grievance selected.",
            "warning"
        );

        return;

    }

    if (!confirm(
        "Are you sure you want to delete this grievance?"
    )) {

        return;

    }

    deleteGrievance();

}

/*==========================================================
 CLEAR FORM
==========================================================*/

function clearForm() {

    document
        .getElementById("cpgramsForm")
        .reset();

    resetEditMode();

    generateGrievanceId();

    clearMessage();

    document
        .getElementById("grievanceNumber")
        .focus();

}

